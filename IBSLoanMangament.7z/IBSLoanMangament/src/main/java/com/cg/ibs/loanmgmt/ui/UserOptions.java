package com.cg.ibs.loanmgmt.ui;

public enum UserOptions {
	EXISTING_CUSTOMER, ADMIN, EXIT
}
